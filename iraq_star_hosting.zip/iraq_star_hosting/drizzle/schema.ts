import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, decimal } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Hosting plans table - يحتوي على خطط الاستضافة المختلفة
 */
export const hostingPlans = mysqlTable("hosting_plans", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(), // اسم الخطة (مثل: Basic, Professional, Enterprise)
  description: text("description"), // وصف الخطة
  price: int("price").notNull(), // السعر بالدينار العراقي (بدون فاصلة عشرية)
  features: text("features"), // المميزات (JSON)
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type HostingPlan = typeof hostingPlans.$inferSelect;
export type InsertHostingPlan = typeof hostingPlans.$inferInsert;

/**
 * Subscribers table - بيانات المشتركين
 */
export const subscribers = mysqlTable("subscribers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // معرف المستخدم (المشترك)
  name: varchar("name", { length: 255 }).notNull(), // اسم المشترك
  email: varchar("email", { length: 320 }).notNull().unique(),
  phone: varchar("phone", { length: 20 }),
  company: varchar("company", { length: 255 }), // اسم الشركة
  planId: int("planId").notNull(), // معرف الخطة المشترك بها
  status: mysqlEnum("status", ["active", "inactive", "suspended", "expired"]).default("active").notNull(),
  subscriptionStartDate: timestamp("subscriptionStartDate").notNull(),
  subscriptionEndDate: timestamp("subscriptionEndDate").notNull(),
  password: varchar("password", { length: 255 }).notNull(), // كلمة مرور المشترك
  notes: text("notes"), // ملاحظات إضافية
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Subscriber = typeof subscribers.$inferSelect;
export type InsertSubscriber = typeof subscribers.$inferInsert;

/**
 * Payments table - سجل المدفوعات
 */
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  subscriberId: int("subscriberId").notNull(), // معرف المشترك
  amount: int("amount").notNull(), // المبلغ بالدينار العراقي
  paymentDate: timestamp("paymentDate").notNull(), // تاريخ الدفع
  paymentMethod: varchar("paymentMethod", { length: 50 }).notNull(), // طريقة الدفع (تحويل بنكي، بطاقة، إلخ)
  status: mysqlEnum("status", ["pending", "completed", "failed", "refunded"]).default("pending").notNull(),
  invoiceNumber: varchar("invoiceNumber", { length: 50 }).unique(), // رقم الفاتورة
  notes: text("notes"), // ملاحظات
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

/**
 * Relations
 */
export const subscribersRelations = relations(subscribers, ({ one, many }) => ({
  plan: one(hostingPlans, {
    fields: [subscribers.planId],
    references: [hostingPlans.id],
  }),
  payments: many(payments),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  subscriber: one(subscribers, {
    fields: [payments.subscriberId],
    references: [subscribers.id],
  }),
}));

export const hostingPlansRelations = relations(hostingPlans, ({ many }) => ({
  subscribers: many(subscribers),
}));