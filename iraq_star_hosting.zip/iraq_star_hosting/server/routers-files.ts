/**
 * إجراءات tRPC لإدارة الملفات والفواتير
 */

import { router, protectedProcedure, adminProcedure } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import * as storageImproved from "./storage-improved";

export const filesRouter = router({
  /**
   * تحميل فاتورة (للمسؤول فقط)
   */
  uploadInvoice: adminProcedure
    .input(
      z.object({
        invoiceNumber: z.string().min(1),
        subscriberId: z.number().positive(),
        pdfBase64: z.string(), // محتوى PDF بصيغة Base64
      })
    )
    .mutation(async ({ input }) => {
      try {
        // تحويل Base64 إلى Buffer
        const pdfBuffer = Buffer.from(input.pdfBase64, "base64");

        // تحميل الفاتورة
        const result = await storageImproved.uploadInvoice(
          input.invoiceNumber,
          pdfBuffer,
          input.subscriberId
        );

        return {
          success: true,
          fileKey: result.fileKey,
          url: result.url,
          message: "تم تحميل الفاتورة بنجاح",
        };
      } catch (error) {
        console.error("[Files] Failed to upload invoice:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل تحميل الفاتورة",
        });
      }
    }),

  /**
   * الحصول على رابط تحميل الفاتورة
   */
  getInvoiceUrl: protectedProcedure
    .input(
      z.object({
        fileKey: z.string().min(1),
      })
    )
    .query(async ({ input }) => {
      try {
        const result = await storageImproved.getFileDownloadUrl({
          fileKey: input.fileKey,
          expiresIn: 3600, // ساعة واحدة
        });

        return {
          success: true,
          url: result.url,
          expiresIn: result.expiresIn,
        };
      } catch (error) {
        console.error("[Files] Failed to get invoice URL:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل الحصول على رابط الفاتورة",
        });
      }
    }),

  /**
   * إنشاء بيانات فاتورة
   */
  createInvoiceData: adminProcedure
    .input(
      z.object({
        invoiceNumber: z.string().min(1),
        subscriberName: z.string().min(1),
        subscriberEmail: z.string().email(),
        amount: z.number().positive(),
        paymentDate: z.date(),
        paymentMethod: z.string().min(1),
        planName: z.string().optional(),
        planPrice: z.number().positive(),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const invoiceData = storageImproved.createInvoiceData({
          invoiceNumber: input.invoiceNumber,
          subscriberName: input.subscriberName,
          subscriberEmail: input.subscriberEmail,
          amount: input.amount,
          paymentDate: input.paymentDate,
          paymentMethod: input.paymentMethod,
          planName: input.planName || "",
          planPrice: input.planPrice,
          description: input.description || "",
        });

        return {
          success: true,
          invoiceData,
          message: "تم إنشاء بيانات الفاتورة بنجاح",
        };
      } catch (error) {
        console.error("[Files] Failed to create invoice data:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل إنشاء بيانات الفاتورة",
        });
      }
    }),

  /**
   * حذف ملف (للمسؤول فقط)
   */
  deleteFile: adminProcedure
    .input(
      z.object({
        fileKey: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const result = await storageImproved.deleteFile(input.fileKey);

        return {
          success: result.success,
          message: result.message,
        };
      } catch (error) {
        console.error("[Files] Failed to delete file:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل حذف الملف",
        });
      }
    }),

  /**
   * الحصول على معلومات الملف
   */
  getFileInfo: protectedProcedure
    .input(
      z.object({
        fileKey: z.string().min(1),
      })
    )
    .query(async ({ input }) => {
      try {
        // استخراج معلومات الملف من المفتاح
        const parts = input.fileKey.split("/");
        const fileName = parts[parts.length - 1];
        const folder = parts[0];

        return {
          success: true,
          fileKey: input.fileKey,
          fileName,
          folder,
          uploadedAt: new Date(),
        };
      } catch (error) {
        console.error("[Files] Failed to get file info:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل الحصول على معلومات الملف",
        });
      }
    }),
});

export type FilesRouter = typeof filesRouter;
