import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import * as db from "./db";
import bcrypt from "bcryptjs";

// Helper to check if user is admin
const adminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user?.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Hosting Plans Router
  plans: router({
    list: publicProcedure.query(() => db.getAllHostingPlans()),
    get: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) =>
      db.getHostingPlanById(input.id)
    ),
    create: adminProcedure
      .input(
        z.object({
          name: z.string().min(1),
          description: z.string().optional(),
          price: z.number().positive(),
          features: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return db.createHostingPlan({
          name: input.name,
          description: input.description,
          price: input.price,
          features: input.features,
          isActive: true,
        });
      }),
    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          description: z.string().optional(),
          price: z.number().positive().optional(),
          features: z.string().optional(),
          isActive: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        return db.updateHostingPlan(id, updates);
      }),
    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.deleteHostingPlan(input.id);
      }),
  }),

  // Subscribers Router
  subscribers: router({
    list: adminProcedure.query(() => db.getAllSubscribers()),
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const subscriber = await db.getSubscriberById(input.id);
        // Allow subscribers to view their own data
        if (subscriber && (ctx.user?.role === "admin" || ctx.user?.id === subscriber.userId)) {
          return subscriber;
        }
        throw new TRPCError({ code: "FORBIDDEN" });
      }),
    create: adminProcedure
      .input(
        z.object({
          name: z.string().min(1),
          email: z.string().email(),
          phone: z.string().optional(),
          company: z.string().optional(),
          planId: z.number(),
          password: z.string().min(6),
          subscriptionStartDate: z.date(),
          subscriptionEndDate: z.date(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const hashedPassword = await bcrypt.hash(input.password, 10);
        return db.createSubscriber({
          userId: 0, // Will be set by admin
          name: input.name,
          email: input.email,
          phone: input.phone,
          company: input.company,
          planId: input.planId,
          password: hashedPassword,
          subscriptionStartDate: input.subscriptionStartDate,
          subscriptionEndDate: input.subscriptionEndDate,
          status: "active",
          notes: input.notes,
        });
      }),
    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          email: z.string().email().optional(),
          phone: z.string().optional(),
          company: z.string().optional(),
          planId: z.number().optional(),
          status: z.enum(["active", "inactive", "suspended", "expired"]).optional(),
          subscriptionStartDate: z.date().optional(),
          subscriptionEndDate: z.date().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        return db.updateSubscriber(id, updates);
      }),
    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.deleteSubscriber(input.id);
      }),
    // Subscriber login
    login: publicProcedure
      .input(z.object({ email: z.string().email(), password: z.string() }))
      .mutation(async ({ input }) => {
        const subscriber = await db.getSubscriberByEmail(input.email);
        if (!subscriber) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Subscriber not found" });
        }
        const isPasswordValid = await bcrypt.compare(input.password, subscriber.password);
        if (!isPasswordValid) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid password" });
        }
        return {
          id: subscriber.id,
          name: subscriber.name,
          email: subscriber.email,
          company: subscriber.company,
          planId: subscriber.planId,
          status: subscriber.status,
          subscriptionStartDate: subscriber.subscriptionStartDate,
          subscriptionEndDate: subscriber.subscriptionEndDate,
        };
      }),
  }),

  // Payments Router
  payments: router({
    list: adminProcedure.query(() => db.getAllPayments()),
    getBySubscriber: protectedProcedure
      .input(z.object({ subscriberId: z.number() }))
      .query(async ({ input, ctx }) => {
        const subscriber = await db.getSubscriberById(input.subscriberId);
        if (subscriber && (ctx.user?.role === "admin" || ctx.user?.id === subscriber.userId)) {
          return db.getPaymentsBySubscriber(input.subscriberId);
        }
        throw new TRPCError({ code: "FORBIDDEN" });
      }),
    create: adminProcedure
      .input(
        z.object({
          subscriberId: z.number(),
          amount: z.number().positive(),
          paymentDate: z.date(),
          paymentMethod: z.string().min(1),
          status: z.enum(["pending", "completed", "failed", "refunded"]).optional(),
          invoiceNumber: z.string().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return db.createPayment({
          subscriberId: input.subscriberId,
          amount: input.amount,
          paymentDate: input.paymentDate,
          paymentMethod: input.paymentMethod,
          status: input.status || "pending",
          invoiceNumber: input.invoiceNumber,
          notes: input.notes,
        });
      }),
    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          amount: z.number().positive().optional(),
          paymentDate: z.date().optional(),
          paymentMethod: z.string().optional(),
          status: z.enum(["pending", "completed", "failed", "refunded"]).optional(),
          invoiceNumber: z.string().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        return db.updatePayment(id, updates);
      }),
    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.deletePayment(input.id);
      }),
  }),
});

export type AppRouter = typeof appRouter;
