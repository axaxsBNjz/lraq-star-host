import { describe, it, expect, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Helper to create admin context
function createAdminContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "admin-user",
      email: "admin@example.com",
      name: "Admin User",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

// Helper to create subscriber context
function createSubscriberContext(): TrpcContext {
  return {
    user: {
      id: 2,
      openId: "subscriber-user",
      email: "subscriber@example.com",
      name: "Subscriber User",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("Hosting Plans API", () => {
  it("should list all active hosting plans", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const plans = await caller.plans.list();
    expect(Array.isArray(plans)).toBe(true);
  });

  it("should get a specific hosting plan by ID", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const plan = await caller.plans.get({ id: 1 });
    // Plan might not exist, but the query should work
    expect(plan === undefined || typeof plan === "object").toBe(true);
  });

  it("should allow admin to create a hosting plan", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.plans.create({
      name: "Test Plan",
      description: "A test hosting plan",
      price: 50000,
      features: JSON.stringify(["Feature 1", "Feature 2"]),
    });

    expect(result).toBeDefined();
  });

  it("should allow admin to update a hosting plan", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.plans.update({
      id: 1,
      name: "Updated Plan",
      price: 60000,
    });

    expect(result).toBeDefined();
  });

  it("should allow admin to delete a hosting plan", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.plans.delete({ id: 1 });
    expect(result).toBeDefined();
  });
});

describe("Subscribers API", () => {
  it("should list all subscribers for admin", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const subscribers = await caller.subscribers.list();
    expect(Array.isArray(subscribers)).toBe(true);
  });

  it("should allow admin to create a subscriber", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.subscribers.create({
      name: "Test Subscriber",
      email: "test@example.com",
      phone: "1234567890",
      company: "Test Company",
      planId: 1,
      password: "SecurePassword123",
      subscriptionStartDate: new Date(),
      subscriptionEndDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
    });

    expect(result).toBeDefined();
  });

  it("should allow admin to update a subscriber", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.subscribers.update({
      id: 1,
      name: "Updated Subscriber",
      status: "active",
    });

    expect(result).toBeDefined();
  });

  it("should allow admin to delete a subscriber", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.subscribers.delete({ id: 1 });
    expect(result).toBeDefined();
  });

  it("should allow subscriber login with valid credentials", async () => {
    const ctx = createSubscriberContext();
    const caller = appRouter.createCaller(ctx);

    // This will fail if the subscriber doesn't exist, but the API should work
    try {
      const result = await caller.subscribers.login({
        email: "test@example.com",
        password: "SecurePassword123",
      });
      expect(result).toBeDefined();
    } catch (error) {
      // Expected if subscriber doesn't exist
      expect(error).toBeDefined();
    }
  });
});

describe("Payments API", () => {
  it("should list all payments for admin", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const payments = await caller.payments.list();
    expect(Array.isArray(payments)).toBe(true);
  });

  it("should allow admin to create a payment", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.payments.create({
      subscriberId: 1,
      amount: 50000,
      paymentDate: new Date(),
      paymentMethod: "Bank Transfer",
      status: "completed",
      invoiceNumber: "INV-001",
    });

    expect(result).toBeDefined();
  });

  it("should allow admin to update a payment", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.payments.update({
      id: 1,
      status: "completed",
      amount: 55000,
    });

    expect(result).toBeDefined();
  });

  it("should allow admin to delete a payment", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.payments.delete({ id: 1 });
    expect(result).toBeDefined();
  });

  it("should allow subscriber to view their own payments", async () => {
    const ctx = createSubscriberContext();
    const caller = appRouter.createCaller(ctx);

    try {
      const payments = await caller.payments.getBySubscriber({ subscriberId: 2 });
      expect(Array.isArray(payments)).toBe(true);
    } catch (error) {
      // Expected if subscriber doesn't have access
      expect(error).toBeDefined();
    }
  });
});

describe("Authentication", () => {
  it("should return current user info", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const user = await caller.auth.me();
    expect(user).toBeDefined();
    expect(user?.role).toBe("admin");
  });

  it("should allow logout", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
  });
});

describe("Authorization", () => {
  it("should prevent non-admin from accessing admin endpoints", async () => {
    const ctx = createSubscriberContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.plans.create({
        name: "Unauthorized Plan",
        price: 50000,
      });
      expect(false).toBe(true); // Should not reach here
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should prevent non-admin from listing all subscribers", async () => {
    const ctx = createSubscriberContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.subscribers.list();
      expect(false).toBe(true); // Should not reach here
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should prevent non-admin from listing all payments", async () => {
    const ctx = createSubscriberContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.payments.list();
      expect(false).toBe(true); // Should not reach here
    } catch (error) {
      expect(error).toBeDefined();
    }
  });
});
