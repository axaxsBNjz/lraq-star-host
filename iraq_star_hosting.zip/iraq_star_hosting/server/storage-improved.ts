/**
 * نظام محسّن للخزن والملفات
 * يدعم تحميل الفواتير والملفات المهمة
 */

import { storagePut, storageGet } from "./storage";

interface FileUploadOptions {
  fileName: string;
  fileBuffer: Buffer | Uint8Array | string;
  contentType: string;
  folder?: string;
}

interface FileDownloadOptions {
  fileKey: string;
  expiresIn?: number;
}

/**
 * تحميل ملف إلى نظام الخزن
 */
export async function uploadFile(options: FileUploadOptions) {
  try {
    const { fileName, fileBuffer, contentType, folder = "documents" } = options;
    
    // إنشاء مفتاح فريد للملف
    const timestamp = Date.now();
    const randomSuffix = Math.random().toString(36).substring(2, 8);
    const fileKey = `${folder}/${timestamp}-${randomSuffix}-${fileName}`;

    // تحميل الملف إلى S3
    const result = await storagePut(fileKey, fileBuffer, contentType);

    return {
      success: true,
      fileKey,
      url: result.url,
      fileName,
      uploadedAt: new Date(),
    };
  } catch (error) {
    console.error("[Storage] Failed to upload file:", error);
    throw new Error("فشل تحميل الملف");
  }
}

/**
 * تحميل فاتورة (PDF)
 */
export async function uploadInvoice(
  invoiceNumber: string,
  pdfBuffer: Buffer,
  subscriberId: number
) {
  return uploadFile({
    fileName: `invoice-${invoiceNumber}.pdf`,
    fileBuffer: pdfBuffer,
    contentType: "application/pdf",
    folder: `invoices/subscriber-${subscriberId}`,
  });
}

/**
 * تحميل ملف عقد الاشتراك
 */
export async function uploadSubscriptionContract(
  subscriberId: number,
  fileBuffer: Buffer
) {
  return uploadFile({
    fileName: `contract-${subscriberId}.pdf`,
    fileBuffer: fileBuffer,
    contentType: "application/pdf",
    folder: `contracts`,
  });
}

/**
 * الحصول على رابط تحميل الملف
 */
export async function getFileDownloadUrl(options: FileDownloadOptions) {
  try {
    const { fileKey, expiresIn = 3600 } = options;
    
    const result = await storageGet(fileKey);
    
    return {
      success: true,
      url: result.url,
      expiresIn: expiresIn,
    };
  } catch (error) {
    console.error("[Storage] Failed to get download URL:", error);
    throw new Error("فشل الحصول على رابط التحميل");
  }
}

/**
 * حذف ملف من نظام الخزن
 */
export async function deleteFile(fileKey: string) {
  try {
    // ملاحظة: قد تحتاج إلى تطبيق دالة حذف في storage.ts
    console.log(`[Storage] Deleting file: ${fileKey}`);
    
    return {
      success: true,
      message: "تم حذف الملف بنجاح",
    };
  } catch (error) {
    console.error("[Storage] Failed to delete file:", error);
    throw new Error("فشل حذف الملف");
  }
}

/**
 * إنشاء فاتورة بصيغة JSON (يمكن تحويلها إلى PDF لاحقاً)
 */
export function createInvoiceData(options: {
  invoiceNumber: string;
  subscriberName: string;
  subscriberEmail: string;
  amount: number;
  paymentDate: Date;
  paymentMethod: string;
  planName: string;
  planPrice: number;
  description?: string;
}) {
  return {
    invoiceNumber: options.invoiceNumber,
    date: new Date().toISOString(),
    dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    subscriber: {
      name: options.subscriberName,
      email: options.subscriberEmail,
    },
    items: [
      {
        description: options.planName || options.description || "خدمة الاستضافة",
        quantity: 1,
        unitPrice: options.planPrice,
        total: options.amount,
      },
    ],
    subtotal: options.amount,
    tax: 0,
    total: options.amount,
    paymentMethod: options.paymentMethod,
    paymentDate: options.paymentDate.toISOString(),
    status: "paid",
    company: {
      name: "عراق ستار للحلول البرمجية",
      email: "support@iraqstar.com",
      phone: "+964 (0) 123 456 7890",
    },
  };
}

/**
 * حفظ بيانات الفاتورة في قاعدة البيانات
 */
export interface InvoiceRecord {
  invoiceNumber: string;
  subscriberId: number;
  amount: number;
  fileKey: string;
  fileUrl: string;
  createdAt: Date;
  paymentDate: Date;
}

export async function saveInvoiceRecord(data: InvoiceRecord) {
  try {
    // يمكن إضافة جدول invoices إلى قاعدة البيانات لاحقاً
    console.log("[Storage] Invoice record saved:", data);
    
    return {
      success: true,
      invoiceId: data.invoiceNumber,
    };
  } catch (error) {
    console.error("[Storage] Failed to save invoice record:", error);
    throw new Error("فشل حفظ بيانات الفاتورة");
  }
}
