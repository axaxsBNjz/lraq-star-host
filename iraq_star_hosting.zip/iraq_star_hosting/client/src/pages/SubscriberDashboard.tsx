import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { LogOut, CreditCard, Calendar, AlertCircle } from "lucide-react";

export default function SubscriberDashboard() {
  const [, setLocation] = useLocation();
  const [isSubscriber, setIsSubscriber] = useState(false);
  const [subscriberData, setSubscriberData] = useState<any>(null);

  useEffect(() => {
    const subscriberSession = localStorage.getItem("subscriberSession");
    if (!subscriberSession) {
      setLocation("/subscriber/login");
    } else {
      setIsSubscriber(true);
      const data = JSON.parse(subscriberSession);
      setSubscriberData(data);
    }
  }, [setLocation]);

  const handleLogout = () => {
    localStorage.removeItem("subscriberSession");
    toast.success("تم تسجيل الخروج");
    setLocation("/subscriber/login");
  };

  if (!isSubscriber) {
    return null;
  }

  // بيانات تجريبية
  const subscriptionData = {
    plan: "الخطة الاحترافية",
    status: "نشط",
    startDate: "2024-01-01",
    endDate: "2025-01-01",
    daysRemaining: 250,
    price: 75000,
  };

  const payments = [
    { id: 1, date: "2024-01-15", amount: 75000, status: "مكتملة", invoice: "INV-001" },
    { id: 2, date: "2023-12-15", amount: 75000, status: "مكتملة", invoice: "INV-002" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">لوحة المشترك</h1>
            <p className="text-sm text-gray-500">{subscriberData?.email}</p>
          </div>
          <Button 
            variant="outline" 
            onClick={handleLogout}
            className="flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            تسجيل الخروج
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Subscription Status Card */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-l-4 border-l-green-500">
            <CardHeader>
              <CardTitle className="text-lg">حالة الاشتراك</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">الخطة:</span>
                  <span className="font-semibold">{subscriptionData.plan}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">الحالة:</span>
                  <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-sm">
                    {subscriptionData.status}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">السعر الشهري:</span>
                  <span className="font-semibold text-blue-600">{subscriptionData.price.toLocaleString()} د.ع</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-blue-500">
            <CardHeader>
              <CardTitle className="text-lg">تاريخ الاشتراك</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">تاريخ البداية:</span>
                  <span className="font-semibold">{subscriptionData.startDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">تاريخ الانتهاء:</span>
                  <span className="font-semibold">{subscriptionData.endDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">الأيام المتبقية:</span>
                  <span className="font-semibold text-orange-600">{subscriptionData.daysRemaining} يوم</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-purple-500">
            <CardHeader>
              <CardTitle className="text-lg">معلومات الدفع</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">آخر دفعة:</span>
                  <span className="font-semibold">2024-01-15</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">الحالة:</span>
                  <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-sm">
                    مكتملة
                  </span>
                </div>
                <Button className="w-full mt-4 bg-blue-600 hover:bg-blue-700">
                  <CreditCard className="w-4 h-4 ml-2" />
                  دفع الآن
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="payments" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="payments" className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              المدفوعات
            </TabsTrigger>
            <TabsTrigger value="support" className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              الدعم الفني
            </TabsTrigger>
          </TabsList>

          {/* Payments Tab */}
          <TabsContent value="payments" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>سجل المدفوعات</CardTitle>
                <CardDescription>جميع المدفوعات والفواتير الخاصة بك</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-right py-2 px-4">التاريخ</th>
                        <th className="text-right py-2 px-4">المبلغ</th>
                        <th className="text-right py-2 px-4">الحالة</th>
                        <th className="text-right py-2 px-4">رقم الفاتورة</th>
                      </tr>
                    </thead>
                    <tbody>
                      {payments.map((payment) => (
                        <tr key={payment.id} className="border-b hover:bg-gray-50">
                          <td className="py-2 px-4">{payment.date}</td>
                          <td className="py-2 px-4">{payment.amount.toLocaleString()} د.ع</td>
                          <td className="py-2 px-4">
                            <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">
                              {payment.status}
                            </span>
                          </td>
                          <td className="py-2 px-4">
                            <a href="#" className="text-blue-600 hover:underline">
                              {payment.invoice}
                            </a>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Support Tab */}
          <TabsContent value="support" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>الدعم الفني</CardTitle>
                <CardDescription>تواصل معنا للحصول على المساعدة</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <h3 className="font-semibold text-blue-900 mb-2">بريد الدعم الفني</h3>
                    <p className="text-blue-800">support@iraqstar.com</p>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                    <h3 className="font-semibold text-green-900 mb-2">رقم الهاتف</h3>
                    <p className="text-green-800">+964 (0) 123 456 7890</p>
                  </div>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    فتح تذكرة دعم جديدة
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
