import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Star, Shield, Zap, Users, Lock, BarChart3 } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      {/* Navigation */}
      <nav className="bg-slate-900 border-b border-slate-700 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-lg flex items-center justify-center">
              <Star className="w-6 h-6 text-white fill-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">عراق ستار</h1>
              <p className="text-xs text-yellow-400">للحلول البرمجية</p>
            </div>
          </div>
          <div className="flex gap-4">
            <Button 
              variant="outline" 
              onClick={() => setLocation("/admin/login")}
              className="border-yellow-500 text-yellow-400 hover:bg-yellow-500 hover:text-slate-900"
            >
              لوحة المسؤول
            </Button>
            <Button 
              onClick={() => setLocation("/subscriber/login")}
              className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-slate-900 hover:from-yellow-500 hover:to-yellow-700 font-semibold"
            >
              دخول المشترك
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-3xl mx-auto">
          <div className="inline-block mb-6">
            <div className="w-24 h-24 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-2xl flex items-center justify-center mx-auto">
              <Star className="w-12 h-12 text-white fill-white" />
            </div>
          </div>
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            خدمات الاستضافة الموثوقة
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            نوفر لك أفضل خدمات استضافة المواقع والتطبيقات بأسعار منافسة وجودة عالية
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Button 
              size="lg"
              onClick={() => setLocation("/subscriber/login")}
              className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-slate-900 hover:from-yellow-500 hover:to-yellow-700 font-semibold px-8"
            >
              ابدأ الآن
            </Button>
            <Button 
              size="lg"
              variant="outline"
              className="border-yellow-500 text-yellow-400 hover:bg-yellow-500 hover:text-slate-900 px-8"
            >
              تعرف على المزيد
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <h3 className="text-3xl font-bold text-white text-center mb-12">
          لماذا تختار عراق ستار؟
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="bg-slate-800 border-slate-700 hover:border-yellow-500 transition-colors">
            <CardHeader>
              <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-slate-900" />
              </div>
              <CardTitle className="text-white">سرعة عالية</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-gray-300">
                خوادم سريعة وموثوقة تضمن أداء موقعك بأفضل شكل
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-yellow-500 transition-colors">
            <CardHeader>
              <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-slate-900" />
              </div>
              <CardTitle className="text-white">أمان عالي</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-gray-300">
                حماية كاملة لموقعك مع شهادات SSL وجدران حماية متقدمة
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-yellow-500 transition-colors">
            <CardHeader>
              <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-slate-900" />
              </div>
              <CardTitle className="text-white">دعم 24/7</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-gray-300">
                فريق دعم فني متخصص جاهز لمساعدتك في أي وقت
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-yellow-500 transition-colors">
            <CardHeader>
              <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mb-4">
                <Lock className="w-6 h-6 text-slate-900" />
              </div>
              <CardTitle className="text-white">خصوصية تامة</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-gray-300">
                بيانات آمنة وسرية مع نسخ احتياطية يومية
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-yellow-500 transition-colors">
            <CardHeader>
              <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mb-4">
                <BarChart3 className="w-6 h-6 text-slate-900" />
              </div>
              <CardTitle className="text-white">إحصائيات مفصلة</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-gray-300">
                لوحة تحكم متقدمة لمراقبة أداء موقعك بشكل مستمر
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-yellow-500 transition-colors">
            <CardHeader>
              <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mb-4">
                <Star className="w-6 h-6 text-slate-900 fill-slate-900" />
              </div>
              <CardTitle className="text-white">أسعار منافسة</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-gray-300">
                خطط متنوعة بأسعار مناسبة لجميع الميزانيات
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="container mx-auto px-4 py-20">
        <h3 className="text-3xl font-bold text-white text-center mb-12">
          خطط الاستضافة
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white text-xl">الخطة الأساسية</CardTitle>
              <CardDescription className="text-gray-300">للمشاريع الصغيرة</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-3xl font-bold text-yellow-400">
                50,000 <span className="text-lg">د.ع</span>
              </div>
              <div className="space-y-2 text-gray-300 text-sm">
                <p>✓ 10 GB مساحة تخزين</p>
                <p>✓ 100 بريد إلكتروني</p>
                <p>✓ دعم فني 24/7</p>
                <p>✓ شهادة SSL مجانية</p>
              </div>
              <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-semibold">
                اختر هذه الخطة
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-b from-yellow-500 to-yellow-600 border-yellow-400 relative">
            <div className="absolute top-0 right-0 bg-yellow-400 text-slate-900 px-3 py-1 text-xs font-bold rounded-bl-lg">
              الأكثر شهرة
            </div>
            <CardHeader>
              <CardTitle className="text-slate-900 text-xl">الخطة الاحترافية</CardTitle>
              <CardDescription className="text-slate-800">للمشاريع المتوسطة</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-3xl font-bold text-slate-900">
                75,000 <span className="text-lg">د.ع</span>
              </div>
              <div className="space-y-2 text-slate-800 text-sm">
                <p>✓ 50 GB مساحة تخزين</p>
                <p>✓ 500 بريد إلكتروني</p>
                <p>✓ دعم فني أولوية</p>
                <p>✓ شهادة SSL مجانية</p>
                <p>✓ نسخ احتياطية يومية</p>
              </div>
              <Button className="w-full bg-slate-900 hover:bg-slate-800 text-yellow-400 font-semibold">
                اختر هذه الخطة
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white text-xl">الخطة الإنتربرايز</CardTitle>
              <CardDescription className="text-gray-300">للمشاريع الكبيرة</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-3xl font-bold text-yellow-400">
                150,000 <span className="text-lg">د.ع</span>
              </div>
              <div className="space-y-2 text-gray-300 text-sm">
                <p>✓ 500 GB مساحة تخزين</p>
                <p>✓ بريد إلكتروني غير محدود</p>
                <p>✓ دعم فني متخصص</p>
                <p>✓ شهادة SSL مجانية</p>
                <p>✓ نسخ احتياطية ساعية</p>
                <p>✓ خادم مخصص</p>
              </div>
              <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-semibold">
                اختر هذه الخطة
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-700 py-8">
        <div className="container mx-auto px-4 text-center text-gray-400">
          <p>&copy; 2024 عراق ستار للحلول البرمجية. جميع الحقوق محفوظة.</p>
          <p className="text-sm mt-2">البريد الإلكتروني: support@iraqstar.com | الهاتف: +964 (0) 123 456 7890</p>
        </div>
      </footer>
    </div>
  );
}
