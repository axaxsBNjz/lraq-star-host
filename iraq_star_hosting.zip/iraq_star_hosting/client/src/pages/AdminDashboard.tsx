import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, Edit2, Trash2, LogOut, Users, Package, CreditCard } from "lucide-react";

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const adminSession = localStorage.getItem("adminSession");
    if (!adminSession) {
      setLocation("/admin/login");
    } else {
      setIsAdmin(true);
    }
  }, [setLocation]);

  const handleLogout = () => {
    localStorage.removeItem("adminSession");
    toast.success("تم تسجيل الخروج");
    setLocation("/admin/login");
  };

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">لوحة تحكم المسؤول</h1>
            <p className="text-sm text-gray-500">عراق ستار للحلول البرمجية</p>
          </div>
          <Button 
            variant="outline" 
            onClick={handleLogout}
            className="flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            تسجيل الخروج
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="subscribers" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="subscribers" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              المشتركين
            </TabsTrigger>
            <TabsTrigger value="plans" className="flex items-center gap-2">
              <Package className="w-4 h-4" />
              الخطط
            </TabsTrigger>
            <TabsTrigger value="payments" className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              المدفوعات
            </TabsTrigger>
          </TabsList>

          {/* Subscribers Tab */}
          <TabsContent value="subscribers" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">إدارة المشتركين</h2>
              <AddSubscriberDialog />
            </div>
            <SubscribersTable />
          </TabsContent>

          {/* Plans Tab */}
          <TabsContent value="plans" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">إدارة خطط الاستضافة</h2>
              <AddPlanDialog />
            </div>
            <PlansTable />
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">سجل المدفوعات</h2>
              <AddPaymentDialog />
            </div>
            <PaymentsTable />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function AddSubscriberDialog() {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    planId: "1",
    password: "",
    subscriptionStartDate: new Date().toISOString().split("T")[0],
    subscriptionEndDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("تم إضافة المشترك بنجاح");
    setOpen(false);
    setFormData({
      name: "",
      email: "",
      phone: "",
      company: "",
      planId: "1",
      password: "",
      subscriptionStartDate: new Date().toISOString().split("T")[0],
      subscriptionEndDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4" />
          إضافة مشترك
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>إضافة مشترك جديد</DialogTitle>
          <DialogDescription>أدخل بيانات المشترك الجديد</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium">الاسم</label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="اسم المشترك"
              required
            />
          </div>
          <div>
            <label className="text-sm font-medium">البريد الإلكتروني</label>
            <Input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="البريد الإلكتروني"
              required
            />
          </div>
          <div>
            <label className="text-sm font-medium">رقم الهاتف</label>
            <Input
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="رقم الهاتف"
            />
          </div>
          <div>
            <label className="text-sm font-medium">اسم الشركة</label>
            <Input
              value={formData.company}
              onChange={(e) => setFormData({ ...formData, company: e.target.value })}
              placeholder="اسم الشركة"
            />
          </div>
          <div>
            <label className="text-sm font-medium">كلمة المرور</label>
            <Input
              type="password"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              placeholder="كلمة المرور"
              required
            />
          </div>
          <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
            إضافة المشترك
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function SubscribersTable() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>قائمة المشتركين</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-right py-2 px-4">الاسم</th>
                <th className="text-right py-2 px-4">البريد الإلكتروني</th>
                <th className="text-right py-2 px-4">الحالة</th>
                <th className="text-right py-2 px-4">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b hover:bg-gray-50">
                <td className="py-2 px-4">محمد أحمد</td>
                <td className="py-2 px-4">mohammed@example.com</td>
                <td className="py-2 px-4">
                  <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">نشط</span>
                </td>
                <td className="py-2 px-4 flex gap-2">
                  <Button size="sm" variant="outline" className="h-8">
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="outline" className="h-8 text-red-600">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}

function AddPlanDialog() {
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4" />
          إضافة خطة
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>إضافة خطة استضافة جديدة</DialogTitle>
        </DialogHeader>
        <form onSubmit={(e) => {
          e.preventDefault();
          toast.success("تم إضافة الخطة بنجاح");
          setOpen(false);
        }} className="space-y-4">
          <Input placeholder="اسم الخطة" required />
          <Input type="number" placeholder="السعر" required />
          <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
            إضافة الخطة
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function PlansTable() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>خطط الاستضافة</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border">
            <CardHeader>
              <CardTitle className="text-lg">الخطة الأساسية</CardTitle>
              <CardDescription>للمشاريع الصغيرة</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600 mb-4">50,000 د.ع</div>
              <div className="space-y-2 text-sm mb-4">
                <p>✓ 10 GB مساحة تخزين</p>
                <p>✓ 100 بريد إلكتروني</p>
                <p>✓ دعم فني 24/7</p>
              </div>
              <Button size="sm" variant="outline" className="w-full">
                <Edit2 className="w-4 h-4 ml-2" />
                تعديل
              </Button>
            </CardContent>
          </Card>
        </div>
      </CardContent>
    </Card>
  );
}

function AddPaymentDialog() {
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4" />
          إضافة دفعة
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>إضافة دفعة جديدة</DialogTitle>
        </DialogHeader>
        <form onSubmit={(e) => {
          e.preventDefault();
          toast.success("تم إضافة الدفعة بنجاح");
          setOpen(false);
        }} className="space-y-4">
          <Input placeholder="رقم المشترك" type="number" required />
          <Input placeholder="المبلغ" type="number" required />
          <Input placeholder="طريقة الدفع" required />
          <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
            إضافة الدفعة
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function PaymentsTable() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>سجل المدفوعات</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-right py-2 px-4">المشترك</th>
                <th className="text-right py-2 px-4">المبلغ</th>
                <th className="text-right py-2 px-4">التاريخ</th>
                <th className="text-right py-2 px-4">الحالة</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b hover:bg-gray-50">
                <td className="py-2 px-4">محمد أحمد</td>
                <td className="py-2 px-4">50,000 د.ع</td>
                <td className="py-2 px-4">2024-01-15</td>
                <td className="py-2 px-4">
                  <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">مكتملة</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
